var CORRECT_USER = 'testact';
var CORRECT_PASS = 'actvn';

var inputUsername = document.getElementById('username');
var inputPassword = document.getElementById('password');

var formLogin = document.getElementById('form-login');

if(formLogin.attachEvent) {
    formLogin.attachEvent('submit', onFormSubmit);
} else {
    formLogin.addEventListener('submit', onFormSubmit);
}


function onFormSubmit(e) {
    if(e.preventDefault) e.preventDefault();

    var username = inputUsername.value;
    var password = inputPassword.value;

    if(username == CORRECT_USER && password == CORRECT_PASS) {
    	
        window.location = 'http://actvn.edu.vn/';
        alert('Đăng nhập thành công');
        

    } else {
        
        if (username=="") {
        	alert('Bạn chưa nhập username! ');

        }
        if (password=="") {
        	alert('Bạn chưa nhập password!');
        }
    	else
    		alert('Tên đăng nhập hoặc mật khẩu không đúng!!');
    }

    return false;
}