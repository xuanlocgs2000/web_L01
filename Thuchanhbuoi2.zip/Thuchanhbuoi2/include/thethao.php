<?php include_once('./layout/header.php');?>

	<article>
			<h3>Thế thao</h3>
			<div class ="new_list">
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content" >
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div style="clear: both;"></div>
					
			</div>
		
