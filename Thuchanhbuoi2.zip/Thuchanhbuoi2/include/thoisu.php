<?php include_once('./layout/header.php');?>

	<article>
			<h3>Thời sự</h3>
			<div class ="new_list">
				<div class="news_item">
					<h4>Một người tử vong sau 39 giờ tiêm vaccine Covid-19</h4>
					<img src="images/vaxcin.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						HÀ NỘI:Sở Y tế chiều 22/6 công bố một nam giáo viên sinh năm 1995 ở huyện Đông Anh, sau tiêm vaccine Covid-19 AstraZeneca hơn một ngày thì xuất hiện co giật tại nhà, tử vong sau đó.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content" >
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div style="clear: both;"></div>
					
			</div>
		

