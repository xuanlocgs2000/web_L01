<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="./style.css">
</head>
<body>
	<div class="container">
		<header>
			<a href="#"><img src="images/manches.png" alt="" width="110px" height="100px"></a>
			
		</header>
		<nav>
			<div class="menu">
				<ul>
					<li><a href="index.php?page_layout=trangchu">Home</a></li>
					<li><a href="index.php?page_layout=thoisu">Thời sự</a></li>
					<li><a href="index.php?page_layout=thethao">Thể thao</a></li>
					<li><a href="index.php?page_layout=thegioi">Thế giới</a></li>
					<li><a href="index.php?page_layout=lienhe">Liên hệ</a></li>
				</ul>
			</div>
		
			<div class="search">
				<input type="search" placeholder="Tìm Kiếm...">
				<button>Tìm kiếm</button>
			</div>
			
		</nav>
		<div id="wrapper">
				<?php

				// $page_layout= [];

				switch ($_GET['page_layout']) {
					case 'trangchu': include_once('index.php');
						// code...
						break;
					case 'thegioi': include_once('./include/thegioi.php');
						// code...
					break;
					case 'thethao': include_once('./include/thethao.php');
						// code...
						break;
						case 'thoisu': include_once('./include/thoisu.php');
						// code...
						break;

					
					
				}

				?>

			</div>