<?php include_once('./layout/header.php');?>

		<div id ="slide">
			<a href=""><img id="anh" src="images/h2.jpg" width="980px" height="400px">
				<script>
        var mang = [            
            'images/h2.jpg',
            'images/h3.jpg',
            'images/h4.jpg'
        ];
        var i = 0;

        function loadImage() {
            document.getElementById('anh').src = mang[i];
            i++;
            if (i == mang.length) {
                i = 0;
            }

            setTimeout('loadImage()', 3000);


        }
        loadImage();
    </script>
			</a>



		</div>

		<article>
			<h3>Tin mới</h3>
			<div class ="new_list">
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content" >
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div style="clear: both;"></div>
					
			</div>
			<h3>Tin EURO 2021</h3>
			<div class ="new_list">
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content">
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div class="news_item">
					<h4>Anh, Pháp chưa đá vẫn vào vòng 1/8 Euro 2021</h4>
					<img src="images/1-7606-1624316618.jpg" alt=""  width="280px" height="180px">
					<div class="content" >
						Anh và Pháp sớm đủ điểm vào vòng knock-out Euro 2021, nhờ Ukraine và Phần Lan đều đứng thứ ba sau vòng bảng tối 21/6.
					</div>
				</div>
				<div style="clear: both;"></div>
					
			</div>
			
			
		</article>
		
		<?php include_once('./layout/footer.php');?>